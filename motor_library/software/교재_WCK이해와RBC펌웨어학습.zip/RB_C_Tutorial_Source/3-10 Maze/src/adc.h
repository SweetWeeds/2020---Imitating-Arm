BYTE	gAD_Ch_Index;
WORD	gVOLTAGE;
BYTE	gDistance;
BYTE	gSoundLevel;
BYTE	gPSD_val;
BYTE	gMIC_val;
signed char	gAD_val;

void Get_AD_PSD(void);
void Get_AD_MIC(void);
void Get_VOLTAGE(void);


