void ReadButton(void);
void ProcButton(void);
void IoUpdate(void);
void ProcIr(void);
void SelfTest1(void);

